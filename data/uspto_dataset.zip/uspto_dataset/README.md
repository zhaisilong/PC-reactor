# USPTO data
Data set derived from:
https://figshare.com/articles/Chemical_reactions_from_US_patents_1976-Sep2016_/5104873

Merge the two train source files with `python merge_src_splits.py`.